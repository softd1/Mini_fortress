using UnityEngine;

[System.Serializable]
public class TowerSaveData
{
    public int typeIndex;
    public Vector3 position;
    public int level;
}