using UnityEngine;

public class EnemyWayPoint : MonoBehaviour
{
    EnemyWayPoint nextWaypoint;

    void Start()
    {
        
    }
    void Update()
    {
        
    }
}
