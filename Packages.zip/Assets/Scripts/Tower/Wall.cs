using UnityEngine;

public class Wall : MonoBehaviour
{
    public bool isOccupied = false;
}
